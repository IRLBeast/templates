# АРМ диспетчера службы эвакуации (ASP.NET Core 8 + SQLite)

Запуск:
    dotnet run
Открыть: http://localhost:5000

База данных (towdispatch.db) создаётся автоматически при первом запуске и заполняется тестовыми данными.
Если установлен другой SDK, поменяйте TargetFramework в TowDispatch.csproj (например, net9.0) и версию пакета EF Core.
