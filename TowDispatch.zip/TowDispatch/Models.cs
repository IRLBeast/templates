using Microsoft.EntityFrameworkCore;

namespace TowDispatch;

public enum TruckStatus { Free, Busy, Offline }

public enum OrderStatus { New, Assigned, EnRoute, Loaded, Completed, Cancelled }

public class Driver
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Phone { get; set; } = "";
}

public class TowTruck
{
    public int Id { get; set; }
    public string PlateNumber { get; set; } = "";
    public string Model { get; set; } = "";
    public int CapacityKg { get; set; }
    public TruckStatus Status { get; set; } = TruckStatus.Free;
    public int? DriverId { get; set; }
    public Driver? Driver { get; set; }
}

public class Order
{
    public int Id { get; set; }
    public DateTime CreatedAt { get; set; }
    public string ClientName { get; set; } = "";
    public string ClientPhone { get; set; } = "";
    public string CarModel { get; set; } = "";
    public string CarPlate { get; set; } = "";
    public int? CarWeightKg { get; set; }
    public string PickupAddress { get; set; } = "";
    public string DropoffAddress { get; set; } = "";
    public double DistanceKm { get; set; }
    public double Price { get; set; }
    public string? Comment { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.New;
    public int? TowTruckId { get; set; }
    public TowTruck? TowTruck { get; set; }
    public DateTime? AssignedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}

public class AppDb : DbContext
{
    public AppDb(DbContextOptions<AppDb> options) : base(options) { }

    public DbSet<Driver> Drivers => Set<Driver>();
    public DbSet<TowTruck> Trucks => Set<TowTruck>();
    public DbSet<Order> Orders => Set<Order>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<TowTruck>().HasIndex(t => t.PlateNumber).IsUnique();
    }
}

// DTO для входных данных
public record DriverInput(string? FullName, string? Phone);
public record TruckInput(string? PlateNumber, string? Model, int CapacityKg, TruckStatus Status, int? DriverId);
public record OrderInput(
    string? ClientName, string? ClientPhone, string? CarModel, string? CarPlate,
    int? CarWeightKg, string? PickupAddress, string? DropoffAddress,
    double DistanceKm, double? Price, string? Comment);
public record AssignInput(int TruckId);
public record StatusInput(OrderStatus Status);
