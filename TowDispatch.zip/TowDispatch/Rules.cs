using System.Text;
using Microsoft.EntityFrameworkCore;

namespace TowDispatch;

public static class Rules
{
    public const double BaseFee = 50.0;   // подача, руб.
    public const double PerKm = 2.5;      // руб. за км

    public static readonly OrderStatus[] ActiveStatuses =
        { OrderStatus.Assigned, OrderStatus.EnRoute, OrderStatus.Loaded };

    // Допустимые переходы статусов (назначение эвакуатора выполняется отдельным действием)
    public static readonly Dictionary<OrderStatus, OrderStatus[]> Next = new()
    {
        [OrderStatus.New] = new[] { OrderStatus.Cancelled },
        [OrderStatus.Assigned] = new[] { OrderStatus.EnRoute, OrderStatus.Cancelled },
        [OrderStatus.EnRoute] = new[] { OrderStatus.Loaded, OrderStatus.Cancelled },
        [OrderStatus.Loaded] = new[] { OrderStatus.Completed },
        [OrderStatus.Completed] = Array.Empty<OrderStatus>(),
        [OrderStatus.Cancelled] = Array.Empty<OrderStatus>(),
    };

    public static double CalcPrice(double km) => Math.Round(BaseFee + km * PerKm, 2);

    public static IQueryable<Order> OrdersQ(AppDb db) =>
        db.Orders.Include(o => o.TowTruck).ThenInclude(t => t!.Driver);

    public static async Task<Order?> LoadOrder(AppDb db, int id) =>
        await OrdersQ(db).FirstOrDefaultAsync(o => o.Id == id);

    public static IQueryable<Order> FilterDates(IQueryable<Order> q, DateTime? dateFrom, DateTime? dateTo)
    {
        if (dateFrom != null) q = q.Where(o => o.CreatedAt >= dateFrom.Value.Date);
        if (dateTo != null) q = q.Where(o => o.CreatedAt < dateTo.Value.Date.AddDays(1));
        return q;
    }

    public static string? ValidateOrder(OrderInput i)
    {
        if (string.IsNullOrWhiteSpace(i.ClientName)) return "Укажите имя клиента";
        if (string.IsNullOrWhiteSpace(i.ClientPhone)) return "Укажите телефон клиента";
        if (string.IsNullOrWhiteSpace(i.CarModel)) return "Укажите марку/модель автомобиля";
        if (string.IsNullOrWhiteSpace(i.PickupAddress)) return "Укажите адрес подачи";
        if (string.IsNullOrWhiteSpace(i.DropoffAddress)) return "Укажите адрес доставки";
        if (i.DistanceKm < 0) return "Расстояние не может быть отрицательным";
        if (i.Price != null && i.Price < 0) return "Стоимость не может быть отрицательной";
        if (i.CarWeightKg != null && i.CarWeightKg <= 0) return "Масса автомобиля должна быть положительной";
        return null;
    }

    public static string RouteUrl(Order o) =>
        "https://www.google.com/maps/dir/?api=1&origin=" + Uri.EscapeDataString(o.PickupAddress) +
        "&destination=" + Uri.EscapeDataString(o.DropoffAddress);

    public static string CsvEscape(string? s)
    {
        s ??= "";
        if (s.Contains('"') || s.Contains(';') || s.Contains('\n') || s.Contains('\r'))
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        return s;
    }

    public static string OrdersCsv(IEnumerable<Order> orders)
    {
        var sb = new StringBuilder();
        sb.AppendLine("№;Создана;Клиент;Телефон;Авто;Госномер;Откуда;Куда;Км;Стоимость;Статус;Эвакуатор;Водитель");
        foreach (var o in orders)
        {
            sb.AppendLine(string.Join(";", new[]
            {
                o.Id.ToString(),
                o.CreatedAt.ToString("yyyy-MM-dd HH:mm"),
                CsvEscape(o.ClientName), CsvEscape(o.ClientPhone),
                CsvEscape(o.CarModel), CsvEscape(o.CarPlate),
                CsvEscape(o.PickupAddress), CsvEscape(o.DropoffAddress),
                o.DistanceKm.ToString(System.Globalization.CultureInfo.InvariantCulture),
                o.Price.ToString(System.Globalization.CultureInfo.InvariantCulture),
                o.Status.ToString(),
                CsvEscape(o.TowTruck?.PlateNumber),
                CsvEscape(o.TowTruck?.Driver?.FullName),
            }));
        }
        return sb.ToString();
    }
}

public static class Seed
{
    public static void Run(AppDb db)
    {
        if (db.Drivers.Any() || db.Trucks.Any() || db.Orders.Any()) return;

        var d1 = new Driver { FullName = "Иванов Пётр Сергеевич", Phone = "+375291112233" };
        var d2 = new Driver { FullName = "Сидоров Алексей Николаевич", Phone = "+375294445566" };
        var d3 = new Driver { FullName = "Козлов Дмитрий Андреевич", Phone = "+375337778899" };
        db.Drivers.AddRange(d1, d2, d3);
        db.SaveChanges();

        var t1 = new TowTruck { PlateNumber = "1234 AB-7", Model = "Iveco Daily", CapacityKg = 3500, DriverId = d1.Id };
        var t2 = new TowTruck { PlateNumber = "5678 KM-7", Model = "Mercedes Sprinter", CapacityKg = 2500, DriverId = d2.Id };
        var t3 = new TowTruck { PlateNumber = "9012 PX-7", Model = "MAN TGL", CapacityKg = 7500, DriverId = d3.Id, Status = TruckStatus.Offline };
        db.Trucks.AddRange(t1, t2, t3);
        db.SaveChanges();

        db.Orders.AddRange(
            new Order
            {
                CreatedAt = DateTime.Now.AddHours(-3), ClientName = "Смирнов Олег", ClientPhone = "+375296001122",
                CarModel = "Toyota Camry", CarPlate = "1111 AA-7", CarWeightKg = 1500,
                PickupAddress = "Минск, пр-т Независимости 50", DropoffAddress = "Минск, ул. Тимирязева 65",
                DistanceKm = 9, Price = Rules.CalcPrice(9), Status = OrderStatus.Completed,
                TowTruckId = t1.Id, AssignedAt = DateTime.Now.AddHours(-3), CompletedAt = DateTime.Now.AddHours(-2)
            },
            new Order
            {
                CreatedAt = DateTime.Now.AddMinutes(-20), ClientName = "Новикова Анна", ClientPhone = "+375447003344",
                CarModel = "Kia Rio", CarPlate = "2222 BB-7", CarWeightKg = 1100,
                PickupAddress = "Минск, ул. Притыцкого 29", DropoffAddress = "Минск, ул. Одоевского 117",
                DistanceKm = 12, Price = Rules.CalcPrice(12), Status = OrderStatus.New
            });
        db.SaveChanges();
    }
}
