using System.Text;
using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using TowDispatch;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDb>(o => o.UseSqlite("Data Source=towdispatch.db"));
builder.Services.ConfigureHttpJsonOptions(o =>
    o.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDb>();
    db.Database.EnsureCreated();
    Seed.Run(db);
}

app.UseDefaultFiles();
app.UseStaticFiles();

IResult Bad(string msg) => Results.BadRequest(new { error = msg });
IResult Conflict(string msg) => Results.Json(new { error = msg }, statusCode: 409);

// ---------------- Тариф ----------------
app.MapGet("/api/tariff", () => new { baseFee = Rules.BaseFee, perKm = Rules.PerKm });

// ---------------- Водители ----------------
var drivers = app.MapGroup("/api/drivers");

drivers.MapGet("/", async (AppDb db) => await db.Drivers.OrderBy(d => d.FullName).ToListAsync());

drivers.MapPost("/", async (DriverInput i, AppDb db) =>
{
    if (string.IsNullOrWhiteSpace(i.FullName)) return Bad("Укажите ФИО водителя");
    if (string.IsNullOrWhiteSpace(i.Phone)) return Bad("Укажите телефон водителя");
    var d = new Driver { FullName = i.FullName.Trim(), Phone = i.Phone.Trim() };
    db.Drivers.Add(d);
    await db.SaveChangesAsync();
    return Results.Ok(d);
});

drivers.MapPut("/{id:int}", async (int id, DriverInput i, AppDb db) =>
{
    var d = await db.Drivers.FindAsync(id);
    if (d == null) return Results.NotFound(new { error = "Водитель не найден" });
    if (string.IsNullOrWhiteSpace(i.FullName)) return Bad("Укажите ФИО водителя");
    if (string.IsNullOrWhiteSpace(i.Phone)) return Bad("Укажите телефон водителя");
    d.FullName = i.FullName.Trim();
    d.Phone = i.Phone.Trim();
    await db.SaveChangesAsync();
    return Results.Ok(d);
});

drivers.MapDelete("/{id:int}", async (int id, AppDb db) =>
{
    var d = await db.Drivers.FindAsync(id);
    if (d == null) return Results.NotFound(new { error = "Водитель не найден" });
    if (await db.Trucks.AnyAsync(t => t.DriverId == id))
        return Conflict("Водитель закреплён за эвакуатором. Сначала снимите его с эвакуатора.");
    db.Drivers.Remove(d);
    await db.SaveChangesAsync();
    return Results.Ok(new { ok = true });
});

// ---------------- Эвакуаторы ----------------
var trucks = app.MapGroup("/api/trucks");

trucks.MapGet("/", async (AppDb db, TruckStatus? status) =>
{
    var q = db.Trucks.Include(t => t.Driver).AsQueryable();
    if (status != null) q = q.Where(t => t.Status == status);
    return await q.OrderBy(t => t.PlateNumber).ToListAsync();
});

trucks.MapPost("/", async (TruckInput i, AppDb db) =>
{
    if (string.IsNullOrWhiteSpace(i.PlateNumber)) return Bad("Укажите госномер");
    if (string.IsNullOrWhiteSpace(i.Model)) return Bad("Укажите модель");
    if (i.CapacityKg <= 0) return Bad("Грузоподъёмность должна быть положительной");
    if (i.Status == TruckStatus.Busy) return Bad("Статус «Занят» устанавливается автоматически при назначении на заявку");
    var plate = i.PlateNumber.Trim();
    if (await db.Trucks.AnyAsync(t => t.PlateNumber == plate)) return Conflict("Эвакуатор с таким госномером уже есть");
    if (i.DriverId != null && !await db.Drivers.AnyAsync(d => d.Id == i.DriverId)) return Bad("Водитель не найден");
    var t = new TowTruck
    {
        PlateNumber = plate, Model = i.Model.Trim(), CapacityKg = i.CapacityKg,
        Status = i.Status, DriverId = i.DriverId
    };
    db.Trucks.Add(t);
    await db.SaveChangesAsync();
    return Results.Ok(await db.Trucks.Include(x => x.Driver).FirstAsync(x => x.Id == t.Id));
});

trucks.MapPut("/{id:int}", async (int id, TruckInput i, AppDb db) =>
{
    var t = await db.Trucks.FindAsync(id);
    if (t == null) return Results.NotFound(new { error = "Эвакуатор не найден" });
    if (string.IsNullOrWhiteSpace(i.PlateNumber)) return Bad("Укажите госномер");
    if (string.IsNullOrWhiteSpace(i.Model)) return Bad("Укажите модель");
    if (i.CapacityKg <= 0) return Bad("Грузоподъёмность должна быть положительной");
    var plate = i.PlateNumber.Trim();
    if (await db.Trucks.AnyAsync(x => x.PlateNumber == plate && x.Id != id)) return Conflict("Эвакуатор с таким госномером уже есть");
    if (i.DriverId != null && !await db.Drivers.AnyAsync(d => d.Id == i.DriverId)) return Bad("Водитель не найден");

    bool hasActive = await db.Orders.AnyAsync(o => o.TowTruckId == id &&
        (o.Status == OrderStatus.Assigned || o.Status == OrderStatus.EnRoute || o.Status == OrderStatus.Loaded));
    if (i.Status != t.Status)
    {
        if (hasActive) return Conflict("Нельзя менять статус эвакуатора, пока у него есть активная заявка");
        if (i.Status == TruckStatus.Busy) return Bad("Статус «Занят» устанавливается автоматически при назначении на заявку");
    }

    t.PlateNumber = plate;
    t.Model = i.Model.Trim();
    t.CapacityKg = i.CapacityKg;
    t.Status = i.Status;
    t.DriverId = i.DriverId;
    await db.SaveChangesAsync();
    return Results.Ok(await db.Trucks.Include(x => x.Driver).FirstAsync(x => x.Id == id));
});

trucks.MapDelete("/{id:int}", async (int id, AppDb db) =>
{
    var t = await db.Trucks.FindAsync(id);
    if (t == null) return Results.NotFound(new { error = "Эвакуатор не найден" });
    if (await db.Orders.AnyAsync(o => o.TowTruckId == id))
        return Conflict("По эвакуатору есть заявки — удаление невозможно. Переведите его в статус «Не в работе».");
    db.Trucks.Remove(t);
    await db.SaveChangesAsync();
    return Results.Ok(new { ok = true });
});

// ---------------- Заявки ----------------
var orders = app.MapGroup("/api/orders");

// Список всех заявок + поиск по критериям
orders.MapGet("/", async (AppDb db, OrderStatus? status, string? q, int? truckId, DateTime? dateFrom, DateTime? dateTo) =>
{
    var query = Rules.OrdersQ(db);
    if (status != null) query = query.Where(o => o.Status == status);
    if (truckId != null) query = query.Where(o => o.TowTruckId == truckId);
    query = Rules.FilterDates(query, dateFrom, dateTo);
    var list = await query.OrderByDescending(o => o.CreatedAt).ToListAsync();

    // текстовый поиск в памяти (SQLite не умеет регистронезависимый поиск по кириллице)
    if (!string.IsNullOrWhiteSpace(q))
    {
        var s = q.Trim();
        bool Has(string? v) => v != null && v.Contains(s, StringComparison.OrdinalIgnoreCase);
        list = list.Where(o => o.Id.ToString() == s || Has(o.ClientName) || Has(o.ClientPhone) ||
            Has(o.CarModel) || Has(o.CarPlate) || Has(o.PickupAddress) || Has(o.DropoffAddress) ||
            Has(o.TowTruck?.PlateNumber)).ToList();
    }
    return list;
});

orders.MapGet("/{id:int}", async (int id, AppDb db) =>
{
    var o = await Rules.LoadOrder(db, id);
    return o == null ? Results.NotFound(new { error = "Заявка не найдена" }) : Results.Ok(o);
});

// Маршрут: ссылка на карту + расчёт стоимости
orders.MapGet("/{id:int}/route", async (int id, AppDb db) =>
{
    var o = await Rules.LoadOrder(db, id);
    if (o == null) return Results.NotFound(new { error = "Заявка не найдена" });
    return Results.Ok(new
    {
        pickup = o.PickupAddress, dropoff = o.DropoffAddress, distanceKm = o.DistanceKm,
        price = o.Price, mapUrl = Rules.RouteUrl(o)
    });
});

orders.MapPost("/", async (OrderInput i, AppDb db) =>
{
    var err = Rules.ValidateOrder(i);
    if (err != null) return Bad(err);
    var o = new Order
    {
        CreatedAt = DateTime.Now,
        ClientName = i.ClientName!.Trim(), ClientPhone = i.ClientPhone!.Trim(),
        CarModel = i.CarModel!.Trim(), CarPlate = (i.CarPlate ?? "").Trim(), CarWeightKg = i.CarWeightKg,
        PickupAddress = i.PickupAddress!.Trim(), DropoffAddress = i.DropoffAddress!.Trim(),
        DistanceKm = i.DistanceKm, Price = i.Price ?? Rules.CalcPrice(i.DistanceKm),
        Comment = string.IsNullOrWhiteSpace(i.Comment) ? null : i.Comment.Trim(),
        Status = OrderStatus.New
    };
    db.Orders.Add(o);
    await db.SaveChangesAsync();
    return Results.Ok(await Rules.LoadOrder(db, o.Id));
});

orders.MapPut("/{id:int}", async (int id, OrderInput i, AppDb db) =>
{
    var o = await db.Orders.FindAsync(id);
    if (o == null) return Results.NotFound(new { error = "Заявка не найдена" });
    if (o.Status == OrderStatus.Completed || o.Status == OrderStatus.Cancelled)
        return Conflict("Завершённую или отменённую заявку редактировать нельзя");
    var err = Rules.ValidateOrder(i);
    if (err != null) return Bad(err);
    o.ClientName = i.ClientName!.Trim();
    o.ClientPhone = i.ClientPhone!.Trim();
    o.CarModel = i.CarModel!.Trim();
    o.CarPlate = (i.CarPlate ?? "").Trim();
    o.CarWeightKg = i.CarWeightKg;
    o.PickupAddress = i.PickupAddress!.Trim();
    o.DropoffAddress = i.DropoffAddress!.Trim();
    o.DistanceKm = i.DistanceKm;
    o.Price = i.Price ?? Rules.CalcPrice(i.DistanceKm);
    o.Comment = string.IsNullOrWhiteSpace(i.Comment) ? null : i.Comment.Trim();
    await db.SaveChangesAsync();
    return Results.Ok(await Rules.LoadOrder(db, id));
});

orders.MapDelete("/{id:int}", async (int id, AppDb db) =>
{
    var o = await db.Orders.FindAsync(id);
    if (o == null) return Results.NotFound(new { error = "Заявка не найдена" });
    if (Rules.ActiveStatuses.Contains(o.Status) && o.TowTruckId != null)
    {
        var t = await db.Trucks.FindAsync(o.TowTruckId);
        if (t != null && t.Status == TruckStatus.Busy) t.Status = TruckStatus.Free;
    }
    db.Orders.Remove(o);
    await db.SaveChangesAsync();
    return Results.Ok(new { ok = true });
});

// Назначение эвакуатора
orders.MapPost("/{id:int}/assign", async (int id, AssignInput input, AppDb db) =>
{
    var o = await db.Orders.FindAsync(id);
    if (o == null) return Results.NotFound(new { error = "Заявка не найдена" });
    if (o.Status != OrderStatus.New) return Conflict("Назначить эвакуатор можно только для новой заявки");
    var t = await db.Trucks.FindAsync(input.TruckId);
    if (t == null) return Bad("Эвакуатор не найден");
    if (t.Status != TruckStatus.Free) return Conflict("Эвакуатор не свободен");
    if (t.DriverId == null) return Conflict("За эвакуатором не закреплён водитель");
    if (o.CarWeightKg is int w && w > t.CapacityKg)
        return Bad($"Масса автомобиля ({w} кг) превышает грузоподъёмность эвакуатора ({t.CapacityKg} кг)");
    o.TowTruckId = t.Id;
    o.Status = OrderStatus.Assigned;
    o.AssignedAt = DateTime.Now;
    t.Status = TruckStatus.Busy;
    await db.SaveChangesAsync();
    return Results.Ok(await Rules.LoadOrder(db, id));
});

// Снятие назначения
orders.MapPost("/{id:int}/unassign", async (int id, AppDb db) =>
{
    var o = await db.Orders.FindAsync(id);
    if (o == null) return Results.NotFound(new { error = "Заявка не найдена" });
    if (o.Status != OrderStatus.Assigned) return Conflict("Снять назначение можно только у заявки в статусе «Назначена»");
    var t = o.TowTruckId == null ? null : await db.Trucks.FindAsync(o.TowTruckId);
    if (t != null) t.Status = TruckStatus.Free;
    o.TowTruckId = null;
    o.AssignedAt = null;
    o.Status = OrderStatus.New;
    await db.SaveChangesAsync();
    return Results.Ok(await Rules.LoadOrder(db, id));
});

// Смена статуса
orders.MapPost("/{id:int}/status", async (int id, StatusInput input, AppDb db) =>
{
    var o = await db.Orders.FindAsync(id);
    if (o == null) return Results.NotFound(new { error = "Заявка не найдена" });
    if (!Rules.Next[o.Status].Contains(input.Status))
        return Conflict($"Переход {o.Status} → {input.Status} недопустим");

    o.Status = input.Status;
    if (input.Status == OrderStatus.Completed || input.Status == OrderStatus.Cancelled)
    {
        if (input.Status == OrderStatus.Completed) o.CompletedAt = DateTime.Now;
        if (o.TowTruckId != null)
        {
            var t = await db.Trucks.FindAsync(o.TowTruckId);
            if (t != null && t.Status == TruckStatus.Busy) t.Status = TruckStatus.Free;
        }
    }
    await db.SaveChangesAsync();
    return Results.Ok(await Rules.LoadOrder(db, id));
});

// ---------------- Отчётность ----------------
var reports = app.MapGroup("/api/reports");

reports.MapGet("/", async (AppDb db, DateTime? dateFrom, DateTime? dateTo) =>
{
    var list = await Rules.FilterDates(Rules.OrdersQ(db), dateFrom, dateTo).ToListAsync();
    var done = list.Where(o => o.Status == OrderStatus.Completed).ToList();

    var byStatus = Enum.GetValues<OrderStatus>()
        .Select(s => new { status = s, count = list.Count(o => o.Status == s) })
        .ToList();

    var byTruck = list.Where(o => o.TowTruck != null)
        .GroupBy(o => o.TowTruckId)
        .Select(g =>
        {
            var tr = g.First().TowTruck!;
            var gd = g.Where(o => o.Status == OrderStatus.Completed).ToList();
            return new
            {
                truck = tr.PlateNumber,
                model = tr.Model,
                driver = tr.Driver?.FullName,
                orders = g.Count(),
                completed = gd.Count,
                km = Math.Round(gd.Sum(o => o.DistanceKm), 1),
                revenue = Math.Round(gd.Sum(o => o.Price), 2)
            };
        })
        .OrderByDescending(x => x.revenue)
        .ToList();

    return Results.Ok(new
    {
        total = list.Count,
        completed = done.Count,
        totalKm = Math.Round(done.Sum(o => o.DistanceKm), 1),
        revenue = Math.Round(done.Sum(o => o.Price), 2),
        averagePrice = done.Count == 0 ? 0 : Math.Round(done.Average(o => o.Price), 2),
        byStatus,
        byTruck
    });
});

reports.MapGet("/orders.csv", async (AppDb db, DateTime? dateFrom, DateTime? dateTo) =>
{
    var list = await Rules.FilterDates(Rules.OrdersQ(db), dateFrom, dateTo)
        .OrderBy(o => o.CreatedAt).ToListAsync();
    var bytes = new UTF8Encoding(true).GetPreamble()
        .Concat(Encoding.UTF8.GetBytes(Rules.OrdersCsv(list))).ToArray();
    return Results.File(bytes, "text/csv; charset=utf-8", "orders.csv");
});

app.Run("http://localhost:5000");
